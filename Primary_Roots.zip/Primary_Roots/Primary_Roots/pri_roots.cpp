#include<stdio.h>
#include<stdlib.h>
#include "mod.h"
#pragma warning(disable: 6031)
#pragma warning(disable: 4996)

int main() {
	Pri_Roots_System();
	return 0;
}
